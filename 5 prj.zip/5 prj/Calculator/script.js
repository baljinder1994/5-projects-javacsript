VanillaTilt.init(document.querySelector(".container"), {
  max: 12,
  speed: 400,
  glare: true,
  "max-glare": 0.2,
});
